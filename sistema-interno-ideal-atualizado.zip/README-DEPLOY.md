# 🚀 GUIA DE DEPLOY - Sistema Interno Ideal

## 📋 PRÉ-REQUISITOS

1. ✅ Projeto funcionando localmente
2. ✅ Credenciais Google Sheets configuradas
3. ✅ Conta Git (GitHub, GitLab, etc.)

---

## 🌟 OPÇÃO 1: RAILWAY (RECOMENDADO)

### Passos:

1. **Criar conta**: https://railway.app
2. **Conectar GitHub**: Autorize acesso ao repositório
3. **Fazer Deploy**:
   - New Project → Deploy from GitHub repo
   - Selecione seu repositório
   - Railway detecta automaticamente Node.js

4. **Configurar Variáveis**:
   - No painel Railway → Variables
   - Adicionar: `NODE_ENV=production`
   - Upload do arquivo credentials.json via interface

5. **Deploy Automático**: ✅ Pronto!

---

## 🎯 OPÇÃO 2: RENDER

### Passos:

1. **Criar conta**: https://render.com
2. **New Web Service**:
   - Connect GitHub repository
   - Name: `sistema-interno-ideal`
   - Branch: `main`
   - Build Command: `npm install`
   - Start Command: `npm start`

3. **Configurar**:
   - Environment: `Node`
   - Plan: `Free` (com limitações)

---

## 🔥 OPÇÃO 3: HEROKU

### Preparação:
```bash
# 1. Instalar Heroku CLI
# 2. Login
heroku login

# 3. Criar app
heroku create sistema-interno-ideal

# 4. Configurar variáveis
heroku config:set NODE_ENV=production

# 5. Deploy
git add .
git commit -m "Deploy setup"
git push heroku main
```

---

## ⚡ OPÇÃO 4: VERCEL

### Preparação:
```bash
# 1. Instalar Vercel CLI
npm i -g vercel

# 2. Deploy
vercel

# 3. Seguir instruções
```

---

## 🛠️ CONFIGURAÇÕES IMPORTANTES

### 1. Variáveis de Ambiente:
```
NODE_ENV=production
PORT=3000
```

### 2. Arquivos necessários:
- ✅ `config/credentials.json` (suas credenciais Google)
- ✅ `config/planilhas.json` (configuração das planilhas)

### 3. Scripts package.json:
```json
{
  "scripts": {
    "start": "node server.js"
  }
}
```

---

## 🔒 SEGURANÇA

### ⚠️ NUNCA COMMITAR:
- `config/credentials.json`
- Arquivos com senhas/tokens

### ✅ FAZER:
- Usar variáveis de ambiente
- Upload manual de credenciais na plataforma
- Configurar .gitignore

---

## 🌐 APÓS DEPLOY

1. **Testar**: Acesse sua URL de produção
2. **Verificar APIs**: 
   - `https://sua-url.com/api/health`
   - `https://sua-url.com/api/unidades`
3. **Monitorar logs** da plataforma escolhida

---

## 🆘 PROBLEMAS COMUNS

### ❌ Erro 503 - Service Unavailable
- **Causa**: Credenciais Google não configuradas
- **Solução**: Upload do arquivo credentials.json

### ❌ Erro de Build
- **Causa**: Dependências ou Node.js version
- **Solução**: Verificar engines no package.json

### ❌ Timeout
- **Causa**: Google Sheets API lenta
- **Solução**: Implementar cache (futuro) 